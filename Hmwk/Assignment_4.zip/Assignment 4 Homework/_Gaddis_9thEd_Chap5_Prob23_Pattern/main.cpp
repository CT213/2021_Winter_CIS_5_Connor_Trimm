/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: 19515
 *
 * Created on January 4, 2021, 12:55 PM
 */

//System Libraries
#include <iostream> //I/O Libary
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal,Conversions, High dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
   
    //Declare Variables
    int num;
    
    
    //Initialize Variables
cin>>num;
    
    //Map inputs to Outputs -> Process
while (num = 10) 
{
    cout<<"+"<<endl;
    cout<<endl;
    cout<<"++"<<endl;
    cout<<endl;
    cout<<"+++"<<endl;
    cout<<endl;
    cout<<"++++"<<endl;
    cout<<endl;
    cout<<"+++++"<<endl;
    cout<<endl;
    cout<<"++++++"<<endl;
    cout<<endl;
    cout<<"+++++++"<<endl;
    cout<<endl;
    cout<<"++++++++"<<endl;
    cout<<endl;
    cout<<"+++++++++"<<endl;
    cout<<endl;
    cout<<"++++++++++"<<endl;
    cout<<endl;
    cout<<"++++++++++"<<endl;
    cout<<endl;
    cout<<"+++++++++"<<endl;
    cout<<endl;
    cout<<"++++++++"<<endl;
    cout<<endl;
    cout<<"+++++++"<<endl;
    cout<<endl;
    cout<<"++++++"<<endl;
    cout<<endl;
    cout<<"+++++"<<endl;
    cout<<endl;
    cout<<"++++"<<endl;
    cout<<endl;
    cout<<"+++"<<endl;
    cout<<endl;
    cout<<"++"<<endl;
    cout<<endl;
    cout<<"+"<<endl; 
    return 0;
}
    //Exit the Program - Cleanup
   
}
    
/*
    0 means equal
    >0 means greater
    <0 means lower

*/

