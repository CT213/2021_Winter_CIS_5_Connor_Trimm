/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Connor Trimm
 * Problem: Diamond Pattern
 * Created on January 5, 2021, 4:03 PM
 */


//System Libraries
#include <iostream> //I/O Libary
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal,Conversions, High dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables

    //Initialize Variables

    
    //Map inputs to Outputs -> Process

    //Display Inputs/Outputs
  
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
    cout<<" ***** "<<endl;
    cout<<"  ***  "<<endl;
    cout<<"   *   "<<endl;
           
    
    //Exit the Program - Cleanup
    return 0;
}
