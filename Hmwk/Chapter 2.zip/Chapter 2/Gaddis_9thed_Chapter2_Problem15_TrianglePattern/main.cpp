
/* 
 * File:   main.cpp
 * Author: Connor Trimm
 * Problem: Triangle Pattern
 * Created on January 5, 2021, 4:04 PM
 */

//System Libraries
#include <iostream> //I/O Libary
#include <cstdlib>
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal,Conversions, High dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
  
    //Initialize Variables
         
    //Map inputs to Outputs -> Process
   
    //Display Inputs/Outputs
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" ***** "<<endl;
    cout<<"*******"<<endl;
           
    
    //Exit the Program - Cleanup
    return 0;
}